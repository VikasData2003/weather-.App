
import React from 'react'
import Weather from './Weather';
import './App.css'
const App = () => {
  return (
    <div>
      <Weather />
    </div>
  )
}

export default App
